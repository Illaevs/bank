<?php
use Bitrix\Main\Context;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

class BankIdeasList extends CBitrixComponent
{
    protected $request;

    public function __construct($component = null)
    {
        parent::__construct($component);
        $this->request = Context::getCurrent()->getRequest();
    }

    public function executeComponent()
    {
        $pageSize = (int)$this->arParams["PAGE_SIZE"] ?: 10;
        $page     = (int)$this->request->get("PAGE");
        if ($page <= 0) $page = 1;

        $status     = trim($this->request->get("STATUS"));
        $authorDept = trim($this->request->get("AUTHOR_DEPT"));
        $targetDept = trim($this->request->get("TARGET_DEPT"));
        $createdBy  = (int)$this->request->get("CREATED_BY");

        $filter = [
            "IBLOCK_ID" => (int)$this->arParams["IBLOCK_ID"],
            "ACTIVE"    => "Y",
        ];

        if ($status !== "") {
            $filter["PROPERTY_STATUS"] = $status;
        }
        if ($authorDept !== "") {
            $filter["PROPERTY_AUTHOR_DEPARTMENT"] = $authorDept;
        }
        if ($targetDept !== "") {
            $filter["PROPERTY_TARGET_DEPARTMENT"] = $targetDept;
        }
        if ($createdBy > 0) {
            $filter["CREATED_BY"] = $createdBy;
        }

        $navParams = [
            "nPageSize" => $pageSize,
            "iNumPage"  => $page,
        ];

        $res = CIBlockElement::GetList(
            ["ACTIVE_FROM" => "DESC", "ID" => "DESC"],
            $filter,
            false,
            $navParams,
            [
                "ID",
                "IBLOCK_ID",
                "NAME",
                "PREVIEW_TEXT",
                "CREATED_BY",
                "ACTIVE_FROM",
                "PROPERTY_LIKE_COUNT",
                "PROPERTY_STATUS",
                "PROPERTY_AUTHOR_DEPARTMENT",
                "PROPERTY_TARGET_DEPARTMENT",
            ]
        );

        $items = [];
        while ($row = $res->GetNext()) {
            $detailUrl = $this->arParams["DETAIL_URL"] ?: "?MODE=view&ID=#ID#";
            $detailUrl = str_replace("#ID#", (int)$row["ID"], $detailUrl);
            $row["DETAIL_URL"] = $detailUrl;

            $row["LIKES"]     = (int)$row["PROPERTY_LIKE_COUNT_VALUE"];
            $row["COMMENTS"]  = $this->countComments($row["ID"]);

            $items[] = $row;
        }

        $navString = $res->GetPageNavString("", "modern", false);

        $this->arResult["ITEMS"]       = $items;
        $this->arResult["NAV_STRING"]  = $navString;
        $this->arResult["FILTER_DATA"] = $this->loadFilterData();

        $this->IncludeComponentTemplate();
    }

    protected function countComments($ideaId)
    {
        $res = CIBlockElement::GetList(
            [],
            [
                "IBLOCK_ID" => 144,
                "ACTIVE"    => "Y",
                "PROPERTY_IDEA" => (int)$ideaId
            ],
            false,
            false,
            ["ID"]
        );
        $cnt = 0;
        while ($res->Fetch()) {
            $cnt++;
        }
        return $cnt;
    }

    protected function loadFilterData()
    {
        $iblockId = (int)$this->arParams["IBLOCK_ID"];

        $statuses = [];
        $authorDepts = [];
        $targetDepts = [];
        $users = [];

        $res = CIBlockElement::GetList(
            [],
            ["IBLOCK_ID" => $iblockId],
            false,
            false,
            [
                "ID",
                "CREATED_BY",
                "PROPERTY_STATUS",
                "PROPERTY_AUTHOR_DEPARTMENT",
                "PROPERTY_TARGET_DEPARTMENT"
            ]
        );

        while ($row = $res->GetNext()) {

            if ($row["PROPERTY_STATUS_VALUE"]) {
                $statuses[$row["PROPERTY_STATUS_VALUE"]] = $row["PROPERTY_STATUS_VALUE"];
            }

            if ($row["PROPERTY_AUTHOR_DEPARTMENT_VALUE"]) {
                $authorDepts[$row["PROPERTY_AUTHOR_DEPARTMENT_VALUE"]] =
                    $row["PROPERTY_AUTHOR_DEPARTMENT_VALUE"];
            }

            if ($row["PROPERTY_TARGET_DEPARTMENT_VALUE"]) {
                $targetDepts[$row["PROPERTY_TARGET_DEPARTMENT_VALUE"]] =
                    $row["PROPERTY_TARGET_DEPARTMENT_VALUE"];
            }

            if ($row["CREATED_BY"]) {
                $uid = (int)$row["CREATED_BY"];
                if (!isset($users[$uid])) {
                    $user = CUser::GetByID($uid)->Fetch();
                    if ($user) {
                        $users[$uid] =
                            trim($user["LAST_NAME"] . " " . $user["NAME"]);
                    }
                }
            }
        }

        return [
            "STATUSES"      => array_values($statuses),
            "AUTHOR_DEPTS"  => array_values($authorDepts),
            "TARGET_DEPTS"  => array_values($targetDepts),
            "USERS"         => $users,
        ];
    }
}
