// ================= ONE-TIME INIT GUARD ======================
if (window.BankIdeasViewInitDone) {
    console.warn("BankIdeasView: prevented reinit");
} else {
    window.BankIdeasViewInitDone = true;

    document.addEventListener("DOMContentLoaded", function () {
        console.log("BankIdeasView: initialized");

        var ajaxUrl = window.BANK_IDEAS_AJAX_URL;
        var sessid  = window.BANK_IDEAS_SESSID;

        function getLikeCookie(id) {
            var name = "liked_idea_" + id + "=";
            var decoded = decodeURIComponent(document.cookie || "");
            var parts = decoded.split(";");
            for (var i = 0; i < parts.length; i++) {
                var c = parts[i].trim();
                if (c.indexOf(name) === 0) return true;
            }
            return false;
        }

        function setLikeCookie(id) {
            var d = new Date();
            d.setFullYear(d.getFullYear() + 5);
            document.cookie = "liked_idea_" + id + "=1;expires=" + d.toUTCString() + ";path=/";
        }

        function ajaxPost(data, cb) {
            data = data || {};
            data.sessid = sessid;

            BX.ajax({
                url: ajaxUrl,
                method: 'POST',
                dataType: 'json',
                data: data,
                onsuccess: function (res) {
                    if (typeof cb === 'function') cb(res);
                },
                onfailure: function () {
                    if (typeof cb === 'function') cb({status: 'error', message: 'ajax error'});
                }
            });
        }

        function renderComments(comments) {
            var list = document.getElementById("idea-comments-list");
            if (!list) return;
            list.innerHTML = "";

            comments.forEach(function (c) {
                var avatarHtml = "";
                if (typeof c.AVATAR === "string") {
                    avatarHtml =
                        '<div class="comment-avatar">' +
                            '<img src="' + BX.util.htmlspecialchars(c.AVATAR) + '" />' +
                        '</div>';
                } else if (c.AVATAR && c.AVATAR.letters) {
                    avatarHtml =
                        '<div class="comment-avatar comment-avatar-initials">' +
                            BX.util.htmlspecialchars(c.AVATAR.letters || "?") +
                        '</div>';
                }

                var html =
                    '<div class="comment-item">' +
                        '<div class="comment-item-inner">' +
                            avatarHtml +
                            '<div class="comment-content">' +
                                '<div class="comment-author"><b>' + BX.util.htmlspecialchars(c.AUTHOR || "Автор неизвестен") + '</b></div>' +
                                '<div class="comment-date">' + BX.util.htmlspecialchars(c.DATE || "") + '</div>' +
                                '<div class="comment-text">' + BX.util.htmlspecialchars(c.TEXT || "") + '</div>' +
                            '</div>' +
                        '</div>' +
                    '</div>';

                list.insertAdjacentHTML("beforeend", html);
            });
        }

        function loadComments() {
            var sendBtn = document.getElementById("idea-comment-send");
            if (!sendBtn) return;

            var ideaId = sendBtn.getAttribute("data-idea-id");
            var cibId  = sendBtn.getAttribute("data-comments-iblock-id");

            ajaxPost({
                action: "load_comments",
                IDEA_ID: ideaId,
                COMMENTS_IBLOCK_ID: cibId
            }, function (res) {
                if (!res || res.status !== "success") return;
                renderComments(res.comments || []);
            });
        }

        var likeBtn = document.querySelector(".btn-like");
        if (likeBtn) {
            likeBtn.addEventListener("click", function () {
                var ideaId = likeBtn.getAttribute("data-idea-id");
                var ibId   = likeBtn.getAttribute("data-iblock-id");

                if (getLikeCookie(ideaId)) {
                    likeBtn.classList.add("liked");
                    return;
                }

                ajaxPost({
                    action: "like",
                    IDEA_ID: ideaId,
                    IBLOCK_ID: ibId
                }, function (res) {
                    if (res && res.status === "success") {
                        setLikeCookie(ideaId);
                        likeBtn.classList.add("liked");
                        var span = likeBtn.querySelector(".like-count");
                        if (span) span.textContent = res.like_count;
                    } else if (res && res.message) {
                        alert(res.message);
                    }
                });
            });
        }

        var sendBtn = document.getElementById("idea-comment-send");
        if (sendBtn) {
            sendBtn.addEventListener("click", function () {
                var textarea = document.getElementById("idea-comment-text");
                if (!textarea) return;
                var text = textarea.value.trim();
                if (!text) {
                    alert("Введите текст комментария");
                    return;
                }

                var ideaId = sendBtn.getAttribute("data-idea-id");
                var cibId  = sendBtn.getAttribute("data-comments-iblock-id");

                ajaxPost({
                    action: "add_comment",
                    IDEA_ID: ideaId,
                    COMMENTS_IBLOCK_ID: cibId,
                    TEXT: text
                }, function (res) {
                    if (res && res.status === "success") {
                        textarea.value = "";
                        loadComments();
                    } else if (res && res.message) {
                        alert(res.message);
                    }
                });
            });
        }

        loadComments();
    });
}
