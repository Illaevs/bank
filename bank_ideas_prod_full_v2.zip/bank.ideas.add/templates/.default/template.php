<?php if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die(); ?>

<div class="ideas-add-wrapper">
    <h2>Подача новой идеи</h2>

    <?php if (!empty($arResult["ERRORS"])): ?>
        <div class="ideas-add-errors">
            <?php foreach ($arResult["ERRORS"] as $err): ?>
                <div><?= htmlspecialcharsbx($err) ?></div>
            <?php endforeach; ?>
        </div>
    <?php endif; ?>

    <form method="post" enctype="multipart/form-data" class="ideas-add-form">
        <?= bitrix_sessid_post() ?>

        <div class="form-row">
            <label>Название идеи *</label>
            <input type="text" name="NAME" value="<?= htmlspecialcharsbx($arResult["OLD"]["NAME"] ?? "") ?>" required>
        </div>

        <div class="form-row">
            <label>Описание идеи *</label>
            <textarea name="DESCRIPTION" rows="4" required><?= htmlspecialcharsbx($arResult["OLD"]["DESCRIPTION"] ?? "") ?></textarea>
        </div>

        <div class="form-row">
            <label>Подразделение автора *</label>
            <input type="text" name="AUTHOR_DEPARTMENT" value="<?= htmlspecialcharsbx($arResult["OLD"]["AUTHOR_DEPARTMENT"] ?? "") ?>" required>
        </div>

        <div class="form-row">
            <label>Подразделение, к которому относится идея *</label>
            <input type="text" name="TARGET_DEPARTMENT" value="<?= htmlspecialcharsbx($arResult["OLD"]["TARGET_DEPARTMENT"] ?? "") ?>" required>
        </div>

        <div class="form-row">
            <label>Файлы (при необходимости)</label>
            <input type="file" name="FILES[]" multiple>
            <div class="hint">Можно прикрепить несколько файлов (документы, изображения и т.п.).</div>
        </div>

        <div class="form-row form-row-buttons">
            <button type="submit" class="btn-primary">Отправить идею</button>
        </div>
    </form>
</div>

<link rel="stylesheet" href="<?= $templateFolder ?>/style.css">
