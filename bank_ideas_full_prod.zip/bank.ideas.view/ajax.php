<?php
define('NO_KEEP_STATISTIC', true);
define('NO_AGENT_STATISTIC', true);
define('STOP_STATISTICS', true);
define('NO_AGENT_CHECK', true);

require $_SERVER["DOCUMENT_ROOT"] . "/bitrix/modules/main/include/prolog_before.php";

use Bitrix\Main\Context;

header('Content-Type: application/json; charset=utf-8');

global $USER;

if (!is_object($USER) || !$USER->IsAuthorized()) {
    echo json_encode(['status' => 'error', 'message' => 'auth required']);
    exit;
}

$request = Context::getCurrent()->getRequest();
$action  = $request->getPost('action');

if (!check_bitrix_sessid()) {
    echo json_encode(['status' => 'error', 'message' => 'bad sessid']);
    exit;
}

if ($action === 'like') {
    $iblockId = (int)$request->getPost('IBLOCK_ID');
    $ideaId   = (int)$request->getPost('IDEA_ID');

    if ($iblockId <= 0 || $ideaId <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'bad params']);
        exit;
    }

    $res = CIBlockElement::GetProperty($iblockId, $ideaId, [], ["CODE" => "LIKE_COUNT"]);
    $like = 0;
    if ($row = $res->Fetch()) {
        $like = (int)$row["VALUE"];
    }
    $like++;

    CIBlockElement::SetPropertyValuesEx($ideaId, $iblockId, ["LIKE_COUNT" => $like]);

    echo json_encode(['status' => 'success', 'like_count' => $like]);
    exit;
}

if ($action === 'load_comments') {
    $cIblockId = (int)$request->getPost('COMMENTS_IBLOCK_ID');
    $ideaId    = (int)$request->getPost('IDEA_ID');

    if ($cIblockId <= 0 || $ideaId <= 0) {
        echo json_encode(['status' => 'error', 'message' => 'bad params']);
        exit;
    }

    $res = CIBlockElement::GetList(
        ["ACTIVE_FROM" => "ASC"],
        ["IBLOCK_ID" => $cIblockId, "ACTIVE" => "Y", "PROPERTY_IDEA" => $ideaId],
        false,
        false,
        ["ID", "PREVIEW_TEXT", "ACTIVE_FROM"]
    );

    $comments = [];
    while ($row = $res->GetNext()) {
        $comments[] = [
            'ID'   => (int)$row['ID'],
            'TEXT' => (string)$row['PREVIEW_TEXT'],
            'DATE' => (string)$row['ACTIVE_FROM'],
        ];
    }

    echo json_encode(['status' => 'success', 'comments' => $comments]);
    exit;
}

if ($action === 'add_comment') {
    $cIblockId = (int)$request->getPost('COMMENTS_IBLOCK_ID');
    $ideaId    = (int)$request->getPost('IDEA_ID');
    $text      = trim((string)$request->getPost('TEXT'));

    if ($cIblockId <= 0 || $ideaId <= 0 || $text === '') {
        echo json_encode(['status' => 'error', 'message' => 'bad params']);
        exit;
    }

    $el = new CIBlockElement();
    $id = $el->Add([
        "IBLOCK_ID"    => $cIblockId,
        "NAME"         => "Комментарий к идее " . $ideaId,
        "PREVIEW_TEXT" => $text,
        "ACTIVE"       => "Y",
        "PROPERTY_VALUES" => [
            "IDEA" => $ideaId,
            "USER" => $USER->GetID(),
        ],
    ]);

    if ($id) {
        echo json_encode(['status' => 'success', 'comment_id' => (int)$id]);
    } else {
        echo json_encode(['status' => 'error', 'message' => $el->LAST_ERROR]);
    }
    exit;
}

echo json_encode(['status' => 'error', 'message' => 'unknown action']);
