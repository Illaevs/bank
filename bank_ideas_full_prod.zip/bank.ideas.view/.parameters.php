<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

$arComponentParameters = [
    "PARAMETERS" => [
        "IBLOCK_ID" => [
            "NAME" => "ID инфоблока Идей",
            "TYPE" => "STRING",
            "DEFAULT" => "143",
        ],
        "COMMENTS_IBLOCK_ID" => [
            "NAME" => "ID инфоблока Комментариев",
            "TYPE" => "STRING",
            "DEFAULT" => "144",
        ],
    ],
];
