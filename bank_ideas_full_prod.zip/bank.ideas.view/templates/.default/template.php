<?php if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die(); ?>

<?php $idea = $arResult["IDEA"]; ?>

<div class="idea-view-wrapper">
    <h2 class="idea-title"><?= htmlspecialcharsbx($idea["NAME"]) ?></h2>

    <div class="idea-meta">
        <?php if ($idea["ACTIVE_FROM"]): ?>
            <span>Дата публикации: <?= htmlspecialcharsbx($idea["ACTIVE_FROM"]) ?></span>
        <?php endif; ?>
        <?php if ($idea["PROPERTY_STATUS_VALUE"]): ?>
            <span>Статус: <?= htmlspecialcharsbx($idea["PROPERTY_STATUS_VALUE"]) ?></span>
        <?php endif; ?>
    </div>

    <div class="idea-section">
        <h3>Описание</h3>
        <p><?= nl2br(htmlspecialcharsbx($idea["PREVIEW_TEXT"])) ?></p>
    </div>

    <?php if ($idea["DETAIL_TEXT"]): ?>
        <div class="idea-section">
            <h3>Подробности</h3>
            <p><?= nl2br(htmlspecialcharsbx($idea["DETAIL_TEXT"])) ?></p>
        </div>
    <?php endif; ?>

    <div class="idea-section idea-files">
        <?php if (!empty($idea["PROPERTY_FILES_VALUE"])): ?>
            <h3>Вложения</h3>
            <ul>
                <?php
                $files = is_array($idea["PROPERTY_FILES_VALUE"])
                    ? $idea["PROPERTY_FILES_VALUE"]
                    : [$idea["PROPERTY_FILES_VALUE"]];
                foreach ($files as $fid):
                    if (!$fid) continue;
                    $file = CFile::GetFileArray($fid);
                    if (!$file) continue;
                ?>
                    <li>
                        <a href="<?= htmlspecialcharsbx($file["SRC"]) ?>" target="_blank">
                            <?= htmlspecialcharsbx($file["ORIGINAL_NAME"] ?: basename($file["SRC"])) ?>
                        </a>
                    </li>
                <?php endforeach; ?>
            </ul>
        <?php endif; ?>
    </div>

    <div class="idea-actions">
        <button
            class="btn-like"
            data-idea-id="<?= (int)$idea["ID"] ?>"
            data-iblock-id="<?= (int)$idea["IBLOCK_ID"] ?>"
        >
            ❤ Нравится (<span class="like-count"><?= (int)$idea["PROPERTY_LIKE_COUNT_VALUE"] ?></span>)
        </button>
    </div>

    <div class="idea-comments">
        <h3>Комментарии</h3>
        <div id="idea-comments-list" class="idea-comments-list">
            <!-- AJAX -->
        </div>

        <div class="idea-comment-form">
            <textarea id="idea-comment-text" rows="3" placeholder="Оставьте комментарий..."></textarea>
            <button
                id="idea-comment-send"
                class="btn-primary"
                data-idea-id="<?= (int)$idea["ID"] ?>"
                data-comments-iblock-id="<?= (int)$arResult["COMMENTS_IBLOCK_ID"] ?>"
            >Отправить</button>
        </div>
    </div>
</div>

<link rel="stylesheet" href="<?= $templateFolder ?>/style.css">
<script>
    window.BANK_IDEAS_AJAX_URL = "<?= CUtil::JSEscape($componentPath . '/ajax.php') ?>";
    window.BANK_IDEAS_SESSID = "<?= bitrix_sessid() ?>";
</script>
<script src="<?= $templateFolder ?>/script.js"></script>
