document.addEventListener("DOMContentLoaded", function () {
    var ajaxUrl = window.BANK_IDEAS_AJAX_URL;
    var sessid = window.BANK_IDEAS_SESSID;

    function ajaxPost(data, cb) {
        data = data || {};
        data.sessid = sessid;

        BX.ajax({
            url: ajaxUrl,
            method: 'POST',
            dataType: 'json',
            data: data,
            onsuccess: function (res) {
                if (typeof cb === 'function') cb(res);
            },
            onfailure: function () {
                if (typeof cb === 'function') cb({status: 'error', message: 'ajax error'});
            }
        });
    }

    function loadComments() {
        var list = document.getElementById('idea-comments-list');
        var sendBtn = document.getElementById('idea-comment-send');
        if (!list || !sendBtn) return;

        var ideaId = sendBtn.getAttribute('data-idea-id');
        var cibId  = sendBtn.getAttribute('data-comments-iblock-id');

        ajaxPost({
            action: 'load_comments',
            IDEA_ID: ideaId,
            COMMENTS_IBLOCK_ID: cibId
        }, function (res) {
            if (!res || res.status !== 'success') return;
            list.innerHTML = '';
            res.comments.forEach(function (c) {
                var div = document.createElement('div');
                div.className = 'comment-item';
                div.innerHTML =
                    '<div class="comment-date">' + BX.util.htmlspecialchars(c.DATE || '') + '</div>' +
                    '<div class="comment-text">' + BX.util.htmlspecialchars(c.TEXT || '') + '</div>';
                list.appendChild(div);
            });
        });
    }

    var likeBtn = document.querySelector('.btn-like');
    if (likeBtn) {
        likeBtn.addEventListener('click', function () {
            var ideaId = likeBtn.getAttribute('data-idea-id');
            var ibId   = likeBtn.getAttribute('data-iblock-id');

            ajaxPost({
                action: 'like',
                IDEA_ID: ideaId,
                IBLOCK_ID: ibId
            }, function (res) {
                if (res && res.status === 'success') {
                    var span = likeBtn.querySelector('.like-count');
                    if (span) span.textContent = res.like_count;
                }
            });
        });
    }

    var sendBtn = document.getElementById('idea-comment-send');
    if (sendBtn) {
        sendBtn.addEventListener('click', function () {
            var textarea = document.getElementById('idea-comment-text');
            var text = textarea.value.trim();
            if (!text) {
                alert('Введите текст комментария');
                return;
            }

            var ideaId = sendBtn.getAttribute('data-idea-id');
            var cibId  = sendBtn.getAttribute('data-comments-iblock-id');

            ajaxPost({
                action: 'add_comment',
                IDEA_ID: ideaId,
                COMMENTS_IBLOCK_ID: cibId,
                TEXT: text
            }, function (res) {
                if (res && res.status === 'success') {
                    textarea.value = '';
                    loadComments();
                } else if (res && res.message) {
                    alert(res.message);
                }
            });
        });
    }

    loadComments();
});
