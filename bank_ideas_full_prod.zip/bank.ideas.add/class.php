<?php
use Bitrix\Main\Context;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

class BankIdeasAdd extends CBitrixComponent
{
    protected $request;
    protected $userId;

    public function __construct($component = null)
    {
        parent::__construct($component);
        $this->request = Context::getCurrent()->getRequest();

        global $USER;
        $this->userId = is_object($USER) && $USER->IsAuthorized() ? (int)$USER->GetID() : 0;
    }

    public function executeComponent()
    {
        if ($this->userId <= 0) {
            ShowError("Для подачи идеи необходимо авторизоваться.");
            return;
        }

        if ($this->request->isPost() && check_bitrix_sessid()) {
            $this->handleSubmit();
        }

        $this->IncludeComponentTemplate();
    }

    protected function handleSubmit()
    {
        $name   = trim($this->request->getPost("NAME"));
        $desc   = trim($this->request->getPost("DESCRIPTION"));
        $depA   = trim($this->request->getPost("AUTHOR_DEPARTMENT"));
        $depT   = trim($this->request->getPost("TARGET_DEPARTMENT"));

        $errors = [];

        if ($name === "")  $errors[] = "Заполните поле «Название»";
        if ($desc === "")  $errors[] = "Заполните поле «Описание идеи»";
        if ($depA === "")  $errors[] = "Заполните поле «Подразделение автора»";
        if ($depT === "")  $errors[] = "Заполните поле «Подразделение идеи»";

        // Обработка файлов
        $files = [];
        if (!empty($_FILES["FILES"]) && is_array($_FILES["FILES"]["name"])) {
            foreach ($_FILES["FILES"]["name"] as $k => $fileName) {
                if (!isset($_FILES["FILES"]["error"][$k]) || $_FILES["FILES"]["error"][$k] !== UPLOAD_ERR_OK) {
                    continue;
                }
                $tmpName = $_FILES["FILES"]["tmp_name"][$k];
                if (!is_uploaded_file($tmpName)) {
                    continue;
                }
                $fileArray = CFile::MakeFileArray($tmpName);
                if ($fileArray) {
                    $fileArray["name"] = $fileName;
                    $files[] = $fileArray;
                }
            }
        }

        if (!empty($errors)) {
            $this->arResult["ERRORS"] = $errors;
            $this->arResult["OLD"] = [
                "NAME" => $name,
                "DESCRIPTION" => $desc,
                "AUTHOR_DEPARTMENT" => $depA,
                "TARGET_DEPARTMENT" => $depT,
            ];
            return;
        }

        $iblockId = (int)$this->arParams["IBLOCK_ID"];

        $el = new CIBlockElement();
        $arFields = [
            "IBLOCK_ID"    => $iblockId,
            "NAME"         => $name,
            "PREVIEW_TEXT" => $desc,
            "CREATED_BY"   => $this->userId,
            "ACTIVE"       => "Y",
            "PROPERTY_VALUES" => [
                "AUTHOR_DEPARTMENT" => $depA,
                "TARGET_DEPARTMENT" => $depT,
                "STATUS"            => "Новая",
            ],
        ];

        if (!empty($files)) {
            $arFields["PROPERTY_VALUES"]["FILES"] = $files;
        }

        $id = $el->Add($arFields);

        if ($id) {
            $url = trim((string)$this->arParams["SUCCESS_URL"]);
            if ($url === "") {
                $url = "?ID=" . (int)$id . "&MODE=view";
            } else {
                $url = str_replace("#ID#", (int)$id, $url);
            }
            LocalRedirect($url);
        } else {
            $this->arResult["ERRORS"] = [$el->LAST_ERROR];
            $this->arResult["OLD"] = [
                "NAME" => $name,
                "DESCRIPTION" => $desc,
                "AUTHOR_DEPARTMENT" => $depA,
                "TARGET_DEPARTMENT" => $depT,
            ];
        }
    }
}
