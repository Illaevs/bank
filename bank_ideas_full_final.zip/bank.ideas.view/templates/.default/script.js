
function getLikeCookie(id){
 return document.cookie.includes("liked_idea_"+id+"=1");
}
function setLikeCookie(id){
 var d=new Date(); d.setFullYear(d.getFullYear()+5);
 document.cookie="liked_idea_"+id+"=1;expires="+d.toUTCString()+";path=/";
}
document.addEventListener("DOMContentLoaded",function(){
 var b=document.querySelector(".btn-like");
 if(b){
  b.addEventListener("click",function(){
    var id=this.dataset.ideaId;
    if(getLikeCookie(id)){ this.classList.add("liked"); return; }
    setLikeCookie(id);
    this.classList.add("liked");
  });
 }
});
