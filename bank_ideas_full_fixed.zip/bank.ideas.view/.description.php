<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
$arComponentDescription = [
    "NAME" => "Банк идей — карточка идеи",
    "DESCRIPTION" => "Просмотр идеи, лайки и комментарии (AJAX, аватары)",
    "PATH" => [
        "ID" => "bank_ideas",
        "NAME" => "Банк идей"
    ],
];
