<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
$arComponentParameters = [
    "PARAMETERS" => [
        "IBLOCK_ID" => [
            "NAME" => "ID инфоблока Идей",
            "TYPE" => "STRING",
            "DEFAULT" => "143",
        ],
        "PAGE_SIZE" => [
            "NAME" => "Количество идей на странице",
            "TYPE" => "STRING",
            "DEFAULT" => "10",
        ],
        "DETAIL_URL" => [
            "NAME" => "Шаблон URL детального просмотра (например, ?MODE=view&ID=#ID#)",
            "TYPE" => "STRING",
            "DEFAULT" => "?MODE=view&ID=#ID#",
        ],
    ],
];
