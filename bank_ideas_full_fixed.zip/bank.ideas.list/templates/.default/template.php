<?php if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die(); ?>

<div class="ideas-list-wrapper">

    <div class="ideas-list-header">
        <h2>Банк идей</h2>
        <a href="?MODE=add" class="btn-primary">Толкни идею</a>
    </div>

    <form method="get" class="ideas-filter">
        <div class="filter-row">

            <select name="STATUS">
                <option value="">Все статусы</option>
                <?php foreach ($arResult['FILTER_DATA']['STATUSES'] as $status): ?>
                    <option value="<?= htmlspecialcharsbx($status) ?>"
                        <?= ($_GET['STATUS'] ?? '') === $status ? 'selected' : '' ?>>
                        <?= htmlspecialcharsbx($status) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <select name="AUTHOR_DEPT">
                <option value="">Подразделение автора</option>
                <?php foreach ($arResult['FILTER_DATA']['AUTHOR_DEPTS'] as $dept): ?>
                    <option value="<?= htmlspecialcharsbx($dept) ?>"
                        <?= ($_GET['AUTHOR_DEPT'] ?? '') === $dept ? 'selected' : '' ?>>
                        <?= htmlspecialcharsbx($dept) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <select name="TARGET_DEPT">
                <option value="">Подразделение идеи</option>
                <?php foreach ($arResult['FILTER_DATA']['TARGET_DEPTS'] as $dept): ?>
                    <option value="<?= htmlspecialcharsbx($dept) ?>"
                        <?= ($_GET['TARGET_DEPT'] ?? '') === $dept ? 'selected' : '' ?>>
                        <?= htmlspecialcharsbx($dept) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <select name="CREATED_BY">
                <option value="">Автор идеи</option>
                <?php foreach ($arResult['FILTER_DATA']['USERS'] as $uid => $uname): ?>
                    <option value="<?= (int)$uid ?>"
                        <?= ($_GET['CREATED_BY'] ?? '') == $uid ? 'selected' : '' ?>>
                        <?= htmlspecialcharsbx($uname) ?>
                    </option>
                <?php endforeach; ?>
            </select>

            <button class="btn-primary">Найти</button>
        </div>
    </form>

    <?php if (empty($arResult["ITEMS"])): ?>
        <div class="ideas-list-empty">Пока нет ни одной идеи.</div>
    <?php else: ?>
        <div class="ideas-list">
            <?php foreach ($arResult["ITEMS"] as $item): ?>
                <div class="idea-card">
                    <h3 class="idea-card-title">
                        <a href="<?= htmlspecialcharsbx($item["DETAIL_URL"]) ?>">
                            <?= htmlspecialcharsbx($item["NAME"]) ?>
                        </a>
                    </h3>
                    <div class="idea-card-meta">
                        <?php if ($item["ACTIVE_FROM"]): ?>
                            <span><?= htmlspecialcharsbx($item["ACTIVE_FROM"]) ?></span>
                        <?php endif; ?>
                        <?php if ($item["PROPERTY_STATUS_VALUE"]): ?>
                            <span>Статус: <?= htmlspecialcharsbx($item["PROPERTY_STATUS_VALUE"]) ?></span>
                        <?php endif; ?>
                    </div>
                    <div class="idea-card-text">
                        <?= nl2br(htmlspecialcharsbx($item["PREVIEW_TEXT"])) ?>
                    </div>
                    <div class="idea-card-footer">
                        <span>❤ <?= (int)$item["LIKES"] ?></span>
                        <span>💬 <?= (int)$item["COMMENTS"] ?></span>
                    </div>
                </div>
            <?php endforeach; ?>
        </div>

        <div class="ideas-list-nav">
            <?= $arResult["NAV_STRING"] ?>
        </div>
    <?php endif; ?>

</div>

<link rel="stylesheet" href="<?= $templateFolder ?>/style.css">
