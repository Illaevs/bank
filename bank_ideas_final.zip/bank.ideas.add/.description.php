<?php
$arComponentDescription=[
 'NAME'=>'Форма добавления идеи',
 'DESCRIPTION'=>'Создание идеи с файлами',
 'PATH'=>['ID'=>'bank_ideas']
];