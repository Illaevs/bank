<?php
require 'class.php';
(new BankIdeasAdd($this))->executeComponent();