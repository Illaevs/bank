<?php
$arComponentParameters=[
 'PARAMETERS'=>[
   'IBLOCK_ID'=>['NAME'=>'ИБ идей','TYPE'=>'STRING','DEFAULT'=>'143'],
   'SUCCESS_URL'=>['NAME'=>'URL после отправки','TYPE'=>'STRING']
 ]
];