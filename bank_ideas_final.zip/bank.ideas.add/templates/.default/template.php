<?php if($arResult['ERROR']): ?><div class="err"><?=$arResult['ERROR']?></div><?php endif; ?>

<form method="post" enctype="multipart/form-data" class="idea-form">
<?=bitrix_sessid_post()?>

<label>Название *</label>
<input type="text" name="NAME" required>

<label>Описание *</label>
<textarea name="DESCRIPTION" required></textarea>

<label>Подразделение автора *</label>
<input type="text" name="AUTHOR_DEPARTMENT" required>

<label>Подразделение идеи *</label>
<input type="text" name="TARGET_DEPARTMENT" required>

<label>Файлы</label>
<input type="file" name="FILES[]" multiple>

<button class="btn">Отправить</button>
</form>
