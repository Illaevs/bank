<?php
use Bitrix\Main\Context;

class BankIdeasAdd extends CBitrixComponent {

 function executeComponent(){
    global $USER;
    if(!$USER->IsAuthorized()){ShowError("Авторизация требуется"); return;}

    $request = Context::getCurrent()->getRequest();

    if($request->isPost() && check_bitrix_sessid()){
        $this->handleSubmit($request, $USER->GetID());
    }

    $this->IncludeComponentTemplate();
 }

 function handleSubmit($r,$userId){
    $name=$r->get('NAME');
    $desc=$r->get('DESCRIPTION');
    $depA=$r->get('AUTHOR_DEPARTMENT');
    $depT=$r->get('TARGET_DEPARTMENT');

    if(!$name||!$desc||!$depA||!$depT){
        $this->arResult['ERROR']="Заполните обязательные поля";
        return;
    }

    // FILES
    $filesArr=[];
    if(!empty($_FILES['FILES'])){
        foreach($_FILES['FILES']['name'] as $k=>$v){
            if($_FILES['FILES']['error'][$k]==0){
                $filesArr[] = CIBlock::makeFileArray([
                    "name"=>$v,
                    "tmp_name"=>$_FILES['FILES']['tmp_name'][$k]
                ]);
            }
        }
    }

    $el=new CIBlockElement();
    $id=$el->Add([
        'IBLOCK_ID'=>$this->arParams['IBLOCK_ID'],
        'NAME'=>$name,
        'PREVIEW_TEXT'=>$desc,
        'CREATED_BY'=>$userId,
        'ACTIVE'=>'Y',
        'PROPERTY_VALUES'=>[
            'AUTHOR_DEPARTMENT'=>$depA,
            'TARGET_DEPARTMENT'=>$depT,
            'STATUS'=>'Новая',
            'FILES'=>$filesArr
        ]
    ]);

    if($id){
        LocalRedirect($this->arParams['SUCCESS_URL'] ?: '?ID='.$id.'&MODE=view');
    } else {
        $this->arResult['ERROR']=$el->LAST_ERROR;
    }
 }
}
