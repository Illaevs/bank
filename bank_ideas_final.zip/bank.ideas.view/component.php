<?php
require 'class.php';
(new BankIdeasView($this))->executeComponent();