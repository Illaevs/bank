<?php
use Bitrix\Main\Context;

class BankIdeasView extends CBitrixComponent {

 function executeComponent(){
    $req = Context::getCurrent()->getRequest();
    $id = (int)$req->get('ID');

    $this->arResult['IDEA']=$this->loadIdea($id);
    $this->arResult['ID']=$id;

    $this->IncludeComponentTemplate();
 }

 function loadIdea($id){
    $res=CIBlockElement::GetList([],['IBLOCK_ID'=>$this->arParams['IBLOCK_ID'],'ID'=>$id],false,false,
        ['ID','NAME','PREVIEW_TEXT','DETAIL_TEXT','PROPERTY_LIKE_COUNT','PROPERTY_FILES']);
    return $res->GetNext();
 }
}
