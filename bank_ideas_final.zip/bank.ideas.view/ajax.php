<?php
require $_SERVER['DOCUMENT_ROOT'].'/bitrix/modules/main/include/prolog_before.php';
header('Content-Type: application/json; charset=utf-8');

global $USER;
if(!$USER->IsAuthorized()){echo json_encode(['error'=>'auth']);exit;}

$act=$_POST['action'];
$idea=(int)$_POST['IDEA_ID'];
$ib=(int)$_POST['IBLOCK_ID'];

if($act=='like'){
    $res=CIBlockElement::GetProperty($ib,$idea,[] ,['CODE'=>'LIKE_COUNT']);
    $like=0; if($ar=$res->Fetch()) $like=(int)$ar['VALUE'];
    $like++;
    CIBlockElement::SetPropertyValuesEx($idea,$ib,['LIKE_COUNT'=>$like]);
    echo json_encode(['success'=>true,'count'=>$like]);
    exit;
}

if($act=='load_comments'){
    $cib=(int)$_POST['CIB'];
    $cs=CIBlockElement::GetList(['ACTIVE_FROM'=>'ASC'],['IBLOCK_ID'=>$cib,'PROPERTY_IDEA'=>$idea],false,false,
        ['ID','PREVIEW_TEXT','ACTIVE_FROM']);
    $out=[];
    while($c=$cs->GetNext()) $out[]=$c;
    echo json_encode(['success'=>true,'comments'=>$out]);
    exit;
}

if($act=='add_comment'){
    $cib=(int)$_POST['CIB'];
    $text=trim($_POST['TEXT']);
    if($text==""){echo json_encode(['error'=>'empty']);exit;}

    $el=new CIBlockElement();
    $el->Add([
        'IBLOCK_ID'=>$cib,
        'NAME'=>'Комментарий',
        'PREVIEW_TEXT'=>$text,
        'PROPERTY_VALUES'=>[
            'IDEA'=>$idea,
            'USER'=>$USER->GetID()
        ]
    ]);
    echo json_encode(['success'=>true]);
    exit;
}

echo json_encode(['error'=>'unknown']);