<?php
$arComponentDescription=['NAME'=>'Просмотр идеи','PATH'=>['ID'=>'bank_ideas']];