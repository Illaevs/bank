window.addEventListener('DOMContentLoaded', ()=>{

let ideaId=document.querySelector('.like-btn')?.dataset.id;

function loadComments(){
 BX.ajax.post('ajax.php',{
   action:'load_comments',
   IDEA_ID:ideaId,
   CIB:document.getElementById('send-comment').dataset.cib
 },res=>{
   let j=JSON.parse(res);
   if(j.success){
     let box=document.getElementById('comments');
     box.innerHTML='';
     j.comments.forEach(c=>{
       let d=document.createElement('div');
       d.className='comment';
       d.innerHTML=`<div class='cdate'>${c.ACTIVE_FROM}</div><div>${c.PREVIEW_TEXT}</div>`;
       box.appendChild(d);
     });
   }
 });
}

loadComments();

document.querySelector('.like-btn')?.addEventListener('click', e=>{
 let btn=e.target;
 BX.ajax.post('ajax.php',{
   action:'like', IDEA_ID:ideaId, IBLOCK_ID:btn.dataset.ib
 },res=>{
   let j=JSON.parse(res);
   if(j.success){
     document.querySelector('.like-count').textContent=j.count;
   }
 });
});

document.getElementById('send-comment').addEventListener('click', e=>{
 let text=document.getElementById('comment-text').value.trim();
 if(!text) return alert("Введите текст");
 BX.ajax.post('ajax.php',{
   action:'add_comment',
   IDEA_ID:ideaId,
   CIB:e.target.dataset.cib,
   TEXT:text
 },()=>{
   document.getElementById('comment-text').value='';
   loadComments();
 });
});

});