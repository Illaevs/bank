<?php $i=$arResult['IDEA']; ?>

<div class="idea-view">
<h1><?=$i['NAME']?></h1>
<p><?=$i['PREVIEW_TEXT']?></p>

<?php if($i['PROPERTY_FILES_VALUE']): ?>
<h3>Файлы:</h3>
<ul>
<?php foreach((array)$i['PROPERTY_FILES_VALUE'] as $fid):
    $f=CFile::GetFileArray($fid); ?>
    <li><a href="<?=$f['SRC']?>" target="_blank"><?=$f['ORIGINAL_NAME']?></a></li>
<?php endforeach; ?>
</ul>
<?php endif; ?>

<button class="like-btn" data-id="<?=$i['ID']?>" data-ib="<?=$i['IBLOCK_ID']?>">
❤ Нравится (<span class="like-count"><?=$i['PROPERTY_LIKE_COUNT_VALUE']?></span>)
</button>

<hr>
<h2>Комментарии</h2>
<div id="comments"></div>

<textarea id="comment-text"></textarea>
<button id="send-comment" data-id="<?=$i['ID']?>" data-cib="<?=$arParams['COMMENTS_IBLOCK_ID']?>">Отправить</button>
</div>

<script src="<?=$templateFolder?>/script.js"></script>
<link rel="stylesheet" href="<?=$templateFolder?>/style.css">
