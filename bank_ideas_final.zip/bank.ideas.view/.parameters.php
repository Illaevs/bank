<?php
$arComponentParameters=['PARAMETERS'=>[
 'IBLOCK_ID'=>['DEFAULT'=>'143'],
 'COMMENTS_IBLOCK_ID'=>['DEFAULT'=>'144']
]];