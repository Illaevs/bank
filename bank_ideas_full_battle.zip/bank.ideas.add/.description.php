<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

$arComponentDescription = [
    "NAME" => "Банк идей — форма добавления идеи",
    "DESCRIPTION" => "Форма создания идеи с загрузкой файлов",
    "PATH" => [
        "ID" => "bank_ideas",
        "NAME" => "Банк идей"
    ],
];
