<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

$arComponentParameters = [
    "PARAMETERS" => [
        "IBLOCK_ID" => [
            "NAME" => "ID инфоблока Идей",
            "TYPE" => "STRING",
            "DEFAULT" => "143",
        ],
        "SUCCESS_URL" => [
            "NAME" => "URL после успешного добавления (по умолчанию ?MODE=view&ID=#ID#)",
            "TYPE" => "STRING",
            "DEFAULT" => "",
        ],
    ],
];
