<?php
if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();
$arComponentDescription = [
    "NAME" => "Банк идей — список идей",
    "DESCRIPTION" => "Список идей с фильтрами, лайками и количеством комментариев",
    "PATH" => [
        "ID" => "bank_ideas",
        "NAME" => "Банк идей"
    ],
];
