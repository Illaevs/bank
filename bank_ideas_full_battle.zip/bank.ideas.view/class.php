<?php
use Bitrix\Main\Context;

if (!defined("B_PROLOG_INCLUDED") || B_PROLOG_INCLUDED !== true) die();

class BankIdeasView extends CBitrixComponent
{
    protected $request;

    public function __construct($component = null)
    {
        parent::__construct($component);
        $this->request = Context::getCurrent()->getRequest();
    }

    public function executeComponent()
    {
        $id = (int)$this->request->get("ID");
        if ($id <= 0) {
            ShowError("Не указан ID идеи.");
            return;
        }

        $idea = $this->loadIdea($id);
        if (!$idea) {
            ShowError("Идея не найдена.");
            return;
        }

        $this->arResult["IDEA"] = $idea;
        $this->arResult["IDEA_ID"] = $id;
        $this->arResult["IBLOCK_ID"] = (int)$this->arParams["IBLOCK_ID"];
        $this->arResult["COMMENTS_IBLOCK_ID"] = (int)$this->arParams["COMMENTS_IBLOCK_ID"];

        $this->IncludeComponentTemplate();
    }

    protected function loadIdea($id)
    {
        $iblockId = (int)$this->arParams["IBLOCK_ID"];

        $res = CIBlockElement::GetList(
            [],
            ["IBLOCK_ID" => $iblockId, "ID" => $id, "ACTIVE" => "Y"],
            false,
            false,
            [
                "ID",
                "IBLOCK_ID",
                "NAME",
                "PREVIEW_TEXT",
                "DETAIL_TEXT",
                "ACTIVE_FROM",
                "PROPERTY_LIKE_COUNT",
                "PROPERTY_FILES",
                "PROPERTY_STATUS",
                "PROPERTY_AUTHOR_DEPARTMENT",
                "PROPERTY_TARGET_DEPARTMENT",
            ]
        );

        if ($row = $res->GetNext()) {
            return $row;
        }
        return null;
    }
}
